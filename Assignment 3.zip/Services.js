// Accordion widget
$(document).ready(function() {
    $("#tabs").accordion({
        event: "click", collapsible: "true", heightStyle: "content"
    });
});